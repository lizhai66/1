import QtQuick

Item {
    id: root

    property string text: "选项"
    property bool selected: false
    property color accent: "#48d9ff"
    signal clicked()

    implicitWidth: 132
    implicitHeight: 44
    opacity: enabled ? 1.0 : 0.38
    scale: tapHandler.pressed ? 0.96 : 1.0

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    Rectangle {
        anchors.fill: parent
        radius: 12
        color: root.selected ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.2)
                             : (hoverHandler.hovered && root.enabled ? "#263b5e" : "#14233e")
        border.width: root.selected ? 2 : 1
        border.color: root.selected ? root.accent : "#385078"
    }

    Text {
        anchors.centerIn: parent
        text: root.enabled ? root.text : root.text + qsTr(" · 锁定")
        color: root.selected ? "white" : "#b9c8e4"
        font.family: uiFont.name
        font.pixelSize: 15
        font.bold: root.selected
    }

    HoverHandler {
        id: hoverHandler
    }

    TapHandler {
        id: tapHandler
        enabled: root.enabled
        acceptedButtons: Qt.LeftButton
        onTapped: root.clicked()
    }

    Behavior on scale {
        NumberAnimation { duration: 90 }
    }
}
