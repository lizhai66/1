#include "gamebackend.h"

#include <algorithm>
#include <array>
#include <cmath>

namespace {
constexpr int maxLevel = 5;

struct LevelData
{
    const char *name;
    const char *mission;
    const char *bossName;
    int target;
    int duration;
    double spawnInterval;
    double hazardRate;
    int bossHealth;
    int bossTimeBonus;
    double bossFireInterval;
};

constexpr std::array<LevelData, maxLevel> levels {{
    {"新兵航道", "收集能量，熟悉飞船操控", "红岩督军", 180, 35, 0.72, 0.24, 34, 22, 1.18},
    {"陨石边境", "高速无人机将加入陨石群", "猎隼指挥机", 320, 40, 0.63, 0.30, 54, 24, 1.02},
    {"风暴星云", "能见度下降，危险持续增强", "星云吞噬者", 480, 45, 0.55, 0.36, 78, 27, 0.88},
    {"双子裂隙", "黑洞出现，注意横向移动", "裂隙守望者", 650, 50, 0.48, 0.41, 112, 30, 0.74},
    {"终极防线", "完成最终守卫并刷新纪录", "零号母舰", 850, 55, 0.42, 0.46, 158, 34, 0.62}
}};
}

GameBackend::GameBackend(QObject *parent)
    : QObject(parent)
{
    m_bestScore = m_settings.value(QStringLiteral("progress/bestScore"), 0).toInt();
    m_unlockedLevel = std::clamp(
        m_settings.value(QStringLiteral("progress/unlockedLevel"), 1).toInt(), 1, maxLevel);
}

int GameBackend::bestScore() const
{
    return m_bestScore;
}

int GameBackend::unlockedLevel() const
{
    return m_unlockedLevel;
}

QVariantMap GameBackend::levelConfig(int level, int difficulty, int players) const
{
    level = std::clamp(level, 1, maxLevel);
    difficulty = std::clamp(difficulty, 0, 2);
    players = std::clamp(players, 1, 2);

    static constexpr std::array<double, 3> targetScale {{0.82, 1.0, 1.18}};
    static constexpr std::array<double, 3> speedScale {{0.84, 1.0, 1.24}};
    static constexpr std::array<double, 3> spawnScale {{1.16, 1.0, 0.82}};
    static constexpr std::array<double, 3> hazardOffset {{-0.05, 0.0, 0.07}};
    static constexpr std::array<int, 3> startingLives {{5, 4, 3}};
    static constexpr std::array<const char *, 3> difficultyNames {{"新手", "标准", "专家"}};

    const auto &data = levels.at(static_cast<std::size_t>(level - 1));
    const double playerTargetScale = players == 2 ? 1.45 : 1.0;

    QVariantMap config;
    config.insert(QStringLiteral("name"), QString::fromUtf8(data.name));
    config.insert(QStringLiteral("mission"), QString::fromUtf8(data.mission));
    config.insert(QStringLiteral("bossName"), QString::fromUtf8(data.bossName));
    config.insert(QStringLiteral("difficultyName"), QString::fromUtf8(difficultyNames.at(difficulty)));
    config.insert(QStringLiteral("targetScore"),
                  qRound(data.target * targetScale.at(difficulty) * playerTargetScale));
    config.insert(QStringLiteral("duration"), data.duration);
    config.insert(QStringLiteral("startingLives"), startingLives.at(difficulty));
    config.insert(QStringLiteral("spawnInterval"), data.spawnInterval * spawnScale.at(difficulty));
    config.insert(QStringLiteral("speedMultiplier"), speedScale.at(difficulty));
    config.insert(QStringLiteral("hazardRate"),
                  std::clamp(data.hazardRate + hazardOffset.at(difficulty), 0.16, 0.64));
    config.insert(QStringLiteral("bossHealth"),
                  qRound(data.bossHealth * targetScale.at(difficulty)
                         * (players == 2 ? 1.55 : 1.0)));
    config.insert(QStringLiteral("bossTimeBonus"), data.bossTimeBonus);
    config.insert(QStringLiteral("bossFireInterval"),
                  data.bossFireInterval * spawnScale.at(difficulty));
    return config;
}

void GameBackend::submitResult(int level, int score, bool victory)
{
    bool changed = false;

    if (score > m_bestScore) {
        m_bestScore = score;
        m_settings.setValue(QStringLiteral("progress/bestScore"), m_bestScore);
        changed = true;
    }

    if (victory && level < maxLevel && m_unlockedLevel < level + 1) {
        m_unlockedLevel = level + 1;
        m_settings.setValue(QStringLiteral("progress/unlockedLevel"), m_unlockedLevel);
        changed = true;
    }

    if (changed) {
        m_settings.sync();
        emit progressChanged();
    }
}

void GameBackend::resetProgress()
{
    m_bestScore = 0;
    m_unlockedLevel = 1;
    m_settings.remove(QStringLiteral("progress"));
    m_settings.sync();
    emit progressChanged();
}
