pragma ComponentBehavior: Bound

import QtQuick
import QtQuick.Window
import QtQml.Models
import "GameLogic.js" as GameLogic

Window {
    id: root

    readonly property int menuState: 0
    readonly property int runningState: 1
    readonly property int pausedState: 2
    readonly property int levelClearState: 3
    readonly property int failedState: 4
    readonly property int campaignClearState: 5
    readonly property int maxLevel: 5

    property var backend: fallbackBackend
    property int gameState: menuState
    property int selectedPlayers: 1
    property int selectedDifficulty: 1
    property int selectedLevel: 1
    property int currentLevel: 1
    property var activeConfig: GameLogic.levelConfig(1, 1, 1)
    property var previewConfig: backend.levelConfig(selectedLevel, selectedDifficulty, selectedPlayers)

    property int levelScore: 0
    property int campaignScore: 0
    readonly property int totalScore: campaignScore + levelScore
    readonly property int activeEntityCount: objectModel.count
    readonly property int activeProjectileCount: projectileModel.count
    readonly property int targetScore: Number(activeConfig.targetScore)
    property int combo: 0
    property int missionPhase: 0
    property int bossHealth: 0
    property int bossMaxHealth: 1
    property real bossCenterX: playfield.width * 0.5
    property real bossDirection: 1
    property real bossFireAccumulator: 0
    property bool bossHitFlash: false
    property string phaseBannerText: ""
    property int skillCharge: 0
    property int selectedUpgrade: -1
    property int bulletDamage: 1
    property real fireInterval: 0.28
    property int bonusLives: 0
    property int maxLives: 4
    property int lives1: 4
    property int lives2: 4
    property real shield1Remaining: 0
    property real shield2Remaining: 0
    property real invulnerable1: 0
    property real invulnerable2: 0
    property real timeRemaining: 35
    property real spawnAccumulator: 0
    property int nextEntityId: 1
    property double lastTick: Date.now()
    property string resultReason: ""

    property real player1CenterX: playfield.width * 0.5
    property real player2CenterX: playfield.width * 0.68
    property bool p1LeftPressed: false
    property bool p1RightPressed: false
    property bool p2LeftPressed: false
    property bool p2RightPressed: false
    property bool p1FirePressed: false
    property bool p2FirePressed: false
    property real fireCooldown1: 0
    property real fireCooldown2: 0
    property int dragPlayer: 1
    property real dragStartCenter: 0

    width: 1180
    height: 760
    minimumWidth: 1120
    minimumHeight: 660
    visible: true
    color: "#050915"
    title: qsTr("星际守卫：协同防线")

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    QtObject {
        id: fallbackBackend

        property int bestScore: 0
        property int unlockedLevel: 1

        function levelConfig(level, difficulty, players) {
            return GameLogic.levelConfig(level, difficulty, players)
        }

        function submitResult(level, score, victory) {
            bestScore = Math.max(bestScore, score)
            if (victory && level < root.maxLevel)
                unlockedLevel = Math.max(unlockedLevel, level + 1)
        }

        function resetProgress() {
            bestScore = 0
            unlockedLevel = 1
        }
    }

    function resetInput() {
        p1LeftPressed = false
        p1RightPressed = false
        p2LeftPressed = false
        p2RightPressed = false
        p1FirePressed = false
        p2FirePressed = false
    }

    function playerIsAlive(playerIndex) {
        return playerIndex === 1 ? lives1 > 0 : selectedPlayers === 2 && lives2 > 0
    }

    function movePlayer(playerIndex, position) {
        var ship = playerIndex === 1 ? player1 : player2
        var halfWidth = ship.width / 2
        var maximum = Math.max(halfWidth, playfield.width - halfWidth)
        var safePosition = GameLogic.clamp(position, halfWidth, maximum)
        if (playerIndex === 1)
            player1CenterX = safePosition
        else
            player2CenterX = safePosition
    }

    function placePlayers() {
        if (selectedPlayers === 2) {
            movePlayer(1, playfield.width * 0.32)
            movePlayer(2, playfield.width * 0.68)
        } else {
            movePlayer(1, playfield.width * 0.5)
        }
    }

    function pointerPlayerForPosition(position) {
        if (selectedPlayers === 1 || lives2 <= 0)
            return 1
        if (lives1 <= 0)
            return 2
        return Math.abs(position - player1CenterX) <= Math.abs(position - player2CenterX) ? 1 : 2
    }

    function startCampaign() {
        campaignScore = 0
        bulletDamage = 1
        fireInterval = 0.28
        bonusLives = 0
        skillCharge = 0
        currentLevel = selectedLevel
        startLevel()
    }

    function startLevel() {
        objectModel.clear()
        projectileModel.clear()
        phaseBannerAnimation.stop()
        phaseBanner.opacity = 0
        activeConfig = backend.levelConfig(currentLevel, selectedDifficulty, selectedPlayers)
        levelScore = 0
        combo = 0
        missionPhase = 0
        bossHealth = 0
        bossMaxHealth = Number(activeConfig.bossHealth)
        bossCenterX = playfield.width * 0.5
        bossDirection = 1
        bossFireAccumulator = 0
        selectedUpgrade = -1
        fireCooldown1 = 0
        fireCooldown2 = 0
        maxLives = Number(activeConfig.startingLives) + bonusLives
        lives1 = maxLives
        lives2 = selectedPlayers === 2 ? maxLives : 0
        shield1Remaining = 0
        shield2Remaining = 0
        invulnerable1 = 0
        invulnerable2 = 0
        timeRemaining = Number(activeConfig.duration)
        spawnAccumulator = Number(activeConfig.spawnInterval) * 0.72
        nextEntityId = 1
        resultReason = ""
        resetInput()
        placePlayers()
        gameState = runningState
        lastTick = Date.now()
        scene.forceActiveFocus()
    }

    function retryLevel() {
        startLevel()
    }

    function advanceToNextLevel() {
        if (selectedUpgrade < 0)
            return
        applySelectedUpgrade()
        campaignScore += levelScore
        currentLevel = Math.min(maxLevel, currentLevel + 1)
        selectedLevel = currentLevel
        startLevel()
    }

    function goToMenu() {
        objectModel.clear()
        projectileModel.clear()
        phaseBannerAnimation.stop()
        phaseBanner.opacity = 0
        resetInput()
        selectedLevel = Math.min(selectedLevel, Number(backend.unlockedLevel))
        currentLevel = selectedLevel
        activeConfig = backend.levelConfig(selectedLevel, selectedDifficulty, selectedPlayers)
        levelScore = 0
        campaignScore = 0
        combo = 0
        missionPhase = 0
        bossHealth = 0
        selectedUpgrade = -1
        maxLives = Number(activeConfig.startingLives)
        lives1 = maxLives
        lives2 = selectedPlayers === 2 ? maxLives : 0
        shield1Remaining = 0
        shield2Remaining = 0
        timeRemaining = Number(activeConfig.duration)
        gameState = menuState
        scene.forceActiveFocus()
    }

    function togglePause() {
        if (gameState === runningState) {
            resetInput()
            gameState = pausedState
        } else if (gameState === pausedState) {
            gameState = runningState
            lastTick = Date.now()
            scene.forceActiveFocus()
        }
    }

    function applySelectedUpgrade() {
        if (selectedUpgrade === 0)
            bulletDamage += 1
        else if (selectedUpgrade === 1)
            fireInterval = Math.max(0.13, fireInterval * 0.80)
        else if (selectedUpgrade === 2)
            bonusLives += 1
    }

    function beginBossBattle() {
        if (missionPhase === 1 || gameState !== runningState)
            return
        objectModel.clear()
        projectileModel.clear()
        missionPhase = 1
        combo = 0
        bossMaxHealth = Number(activeConfig.bossHealth)
        bossHealth = bossMaxHealth
        bossCenterX = playfield.width * 0.5
        bossDirection = 1
        bossFireAccumulator = 0
        timeRemaining += Number(activeConfig.bossTimeBonus)
        phaseBannerText = qsTr("警告：%1 已进入战场").arg(String(activeConfig.bossName))
        phaseBannerAnimation.restart()
    }

    function shoot(playerIndex) {
        if (gameState !== runningState || !playerIsAlive(playerIndex))
            return
        if ((playerIndex === 1 && fireCooldown1 > 0)
                || (playerIndex === 2 && fireCooldown2 > 0))
            return

        var ship = playerIndex === 1 ? player1 : player2
        var center = playerIndex === 1 ? player1CenterX : player2CenterX
        projectileModel.append({
            projectileOwner: playerIndex,
            projectileX: center,
            projectileY: ship.y + 8,
            projectileSpeed: -590,
            projectileVX: 0,
            projectileSize: 12,
            projectileDamage: bulletDamage
        })

        if (playerIndex === 1)
            fireCooldown1 = fireInterval
        else
            fireCooldown2 = fireInterval
    }

    function spawnBossProjectile() {
        var projectileCount = currentLevel >= 4 ? 5 : (currentLevel >= 2 ? 3 : 1)
        var middle = (projectileCount - 1) / 2
        var speed = (220 + currentLevel * 24) * Number(activeConfig.speedMultiplier)
        for (var i = 0; i < projectileCount; ++i) {
            projectileModel.append({
                projectileOwner: 0,
                projectileX: bossCenterX,
                projectileY: bossItem.y + bossItem.height * 0.78,
                projectileSpeed: speed,
                projectileVX: (i - middle) * (54 + currentLevel * 7),
                projectileSize: currentLevel >= 5 ? 17 : 14,
                projectileDamage: currentLevel >= 5 && i === middle ? 2 : 1
            })
        }
    }

    function damageBoss(amount) {
        if (missionPhase !== 1 || gameState !== runningState)
            return
        bossHealth = Math.max(0, bossHealth - amount)
        bossHitFlash = true
        bossHitTimer.restart()
        if (bossHealth <= 0) {
            levelScore += 100 * currentLevel
            completeLevel()
        }
    }

    function activateBurst() {
        if (gameState !== runningState || skillCharge < 100)
            return
        skillCharge = 0
        for (var i = objectModel.count - 1; i >= 0; --i) {
            if (GameLogic.isHazard(objectModel.get(i).entityType))
                objectModel.remove(i)
        }
        for (var j = projectileModel.count - 1; j >= 0; --j) {
            if (projectileModel.get(j).projectileOwner === 0)
                projectileModel.remove(j)
        }
        if (missionPhase === 1)
            damageBoss(12 + bulletDamage * 6)
        phaseBannerText = qsTr("战术爆发：敌方火力已净化")
        phaseBannerAnimation.restart()
        burstAnimation.restart()
    }

    function completeLevel() {
        objectModel.clear()
        projectileModel.clear()
        phaseBannerAnimation.stop()
        phaseBanner.opacity = 0
        resetInput()
        resultReason = qsTr("守关首领已被击破，航道完全安全")
        backend.submitResult(currentLevel, totalScore, true)
        gameState = currentLevel >= maxLevel ? campaignClearState : levelClearState
    }

    function failLevel(reason) {
        objectModel.clear()
        projectileModel.clear()
        phaseBannerAnimation.stop()
        phaseBanner.opacity = 0
        resetInput()
        resultReason = reason
        backend.submitResult(currentLevel, totalScore, false)
        gameState = failedState
    }

    function spawnEntity() {
        if (objectModel.count >= 38)
            return
        objectModel.append(GameLogic.createEntity(playfield.width, currentLevel,
                                                   activeConfig, nextEntityId++))
    }

    function damagePlayer(playerIndex, amount) {
        if (playerIndex === 1) {
            if (shield1Remaining > 0) {
                shield1Remaining = 0
                shieldAnimation1.restart()
                return
            }
            if (invulnerable1 > 0)
                return
            lives1 = Math.max(0, lives1 - amount)
            invulnerable1 = 1.15
        } else {
            if (shield2Remaining > 0) {
                shield2Remaining = 0
                shieldAnimation2.restart()
                return
            }
            if (invulnerable2 > 0)
                return
            lives2 = Math.max(0, lives2 - amount)
            invulnerable2 = 1.15
        }

        combo = 0
        damageAnimation.restart()
        if (lives1 <= 0 && (selectedPlayers === 1 || lives2 <= 0))
            failLevel(qsTr("守卫飞船全部失去动力"))
    }

    function collectEntity(type, playerIndex) {
        if (GameLogic.isHazard(type)) {
            damagePlayer(playerIndex, GameLogic.damageForType(type))
            return
        }

        combo += type === 2 ? 2 : 1
        levelScore += GameLogic.scoreForType(type, combo)
        skillCharge = Math.min(100, skillCharge + (type === 2 ? 22 : (type === 3 ? 16 : 7)))

        if (type === 2) {
            if (playerIndex === 1)
                lives1 = Math.min(maxLives, lives1 + 1)
            else
                lives2 = Math.min(maxLives, lives2 + 1)
        } else if (type === 3) {
            if (playerIndex === 1)
                shield1Remaining = 7
            else
                shield2Remaining = 7
        } else if (type === 5) {
            timeRemaining = Math.min(Number(activeConfig.duration) + 12, timeRemaining + 6)
        }

        if (missionPhase === 0 && levelScore >= targetScore)
            beginBossBattle()
    }

    function hitTestPlayer(playerIndex, xPosition, yPosition, objectSize) {
        if (!playerIsAlive(playerIndex))
            return false
        var ship = playerIndex === 1 ? player1 : player2
        var center = playerIndex === 1 ? player1CenterX : player2CenterX
        return GameLogic.intersects(
                    center - ship.width * 0.36, ship.y + ship.height * 0.18,
                    ship.width * 0.72, ship.height * 0.70,
                    xPosition - objectSize / 2, yPosition - objectSize / 2,
                    objectSize, objectSize)
    }

    function hitPlayerForEntity(xPosition, yPosition, objectSize) {
        var hit1 = hitTestPlayer(1, xPosition, yPosition, objectSize)
        var hit2 = selectedPlayers === 2 && hitTestPlayer(2, xPosition, yPosition, objectSize)
        if (hit1 && hit2)
            return Math.abs(xPosition - player1CenterX) <= Math.abs(xPosition - player2CenterX) ? 1 : 2
        if (hit1)
            return 1
        return hit2 ? 2 : 0
    }

    function updateProjectiles(delta) {
        for (var projectileIndex = projectileModel.count - 1; projectileIndex >= 0; --projectileIndex) {
            var projectile = projectileModel.get(projectileIndex)
            var nextX = projectile.projectileX + projectile.projectileVX * delta
            var nextY = projectile.projectileY + projectile.projectileSpeed * delta
            var size = projectile.projectileSize

            if (projectile.projectileOwner > 0) {
                if (missionPhase === 1 && GameLogic.intersects(
                            nextX - size / 2, nextY - size / 2, size, size,
                            bossItem.x + bossItem.width * 0.12,
                            bossItem.y + bossItem.height * 0.12,
                            bossItem.width * 0.76, bossItem.height * 0.78)) {
                    var bossDamage = projectile.projectileDamage
                    projectileModel.remove(projectileIndex)
                    damageBoss(bossDamage)
                    if (gameState !== runningState)
                        return
                    continue
                }

                var destroyedEntity = -1
                for (var entityIndex = objectModel.count - 1; entityIndex >= 0; --entityIndex) {
                    var targetEntity = objectModel.get(entityIndex)
                    if (!GameLogic.isHazard(targetEntity.entityType))
                        continue
                    if (GameLogic.intersects(
                                nextX - size / 2, nextY - size / 2, size, size,
                                targetEntity.entityX - targetEntity.entitySize / 2,
                                targetEntity.entityY - targetEntity.entitySize / 2,
                                targetEntity.entitySize, targetEntity.entitySize)) {
                        destroyedEntity = entityIndex
                        var destroyedType = targetEntity.entityType
                        objectModel.remove(entityIndex)
                        projectileModel.remove(projectileIndex)
                        combo += 1
                        levelScore += GameLogic.destroyScore(destroyedType)
                        skillCharge = Math.min(100, skillCharge + 5)
                        if (missionPhase === 0 && levelScore >= targetScore) {
                            beginBossBattle()
                            return
                        }
                        break
                    }
                }
                if (destroyedEntity >= 0)
                    continue
            } else {
                var hitPlayer = hitPlayerForEntity(nextX, nextY, size)
                if (hitPlayer > 0) {
                    var damage = projectile.projectileDamage
                    projectileModel.remove(projectileIndex)
                    damagePlayer(hitPlayer, damage)
                    if (gameState !== runningState)
                        return
                    continue
                }
            }

            if (nextY < -40 || nextY > playfield.height + 40
                    || nextX < -40 || nextX > playfield.width + 40) {
                projectileModel.remove(projectileIndex)
            } else {
                projectileModel.setProperty(projectileIndex, "projectileX", nextX)
                projectileModel.setProperty(projectileIndex, "projectileY", nextY)
            }
        }
    }

    function advanceFrame() {
        var now = Date.now()
        var delta = Math.min(0.05, Math.max(0, (now - lastTick) / 1000))
        lastTick = now

        if (gameState !== runningState)
            return

        shield1Remaining = Math.max(0, shield1Remaining - delta)
        shield2Remaining = Math.max(0, shield2Remaining - delta)
        invulnerable1 = Math.max(0, invulnerable1 - delta)
        invulnerable2 = Math.max(0, invulnerable2 - delta)
        fireCooldown1 = Math.max(0, fireCooldown1 - delta)
        fireCooldown2 = Math.max(0, fireCooldown2 - delta)

        var movementSpeed = 390
        var direction1 = (p1RightPressed ? 1 : 0) - (p1LeftPressed ? 1 : 0)
        var direction2 = (p2RightPressed ? 1 : 0) - (p2LeftPressed ? 1 : 0)
        if (direction1 !== 0 && lives1 > 0)
            movePlayer(1, player1CenterX + direction1 * movementSpeed * delta)
        if (direction2 !== 0 && lives2 > 0)
            movePlayer(2, player2CenterX + direction2 * movementSpeed * delta)
        if (p1FirePressed)
            shoot(1)
        if (p2FirePressed)
            shoot(2)

        timeRemaining -= delta
        if (timeRemaining <= 0) {
            timeRemaining = 0
            failLevel(missionPhase === 1 ? qsTr("首领战超时，防线被突破")
                                        : qsTr("时间耗尽，未达到本关目标"))
            return
        }

        if (missionPhase === 0) {
            spawnAccumulator += delta
            var progress = targetScore > 0 ? levelScore / targetScore : 0
            var interval = GameLogic.currentSpawnInterval(Number(activeConfig.spawnInterval), progress)
            while (spawnAccumulator >= interval) {
                spawnAccumulator -= interval
                spawnEntity()
            }
        } else {
            var halfBoss = bossItem.width / 2
            bossCenterX += bossDirection * (92 + currentLevel * 18) * delta
            if (bossCenterX < halfBoss || bossCenterX > playfield.width - halfBoss) {
                bossDirection = -bossDirection
                bossCenterX = GameLogic.clamp(bossCenterX, halfBoss, playfield.width - halfBoss)
            }
            bossFireAccumulator += delta
            if (bossFireAccumulator >= Number(activeConfig.bossFireInterval)) {
                bossFireAccumulator = 0
                spawnBossProjectile()
            }
        }

        for (var i = objectModel.count - 1; i >= 0; --i) {
            var entity = objectModel.get(i)
            var nextY = entity.entityY + entity.entitySpeed * delta
            var nextX = entity.entityX + entity.entityVX * delta
            var nextVX = entity.entityVX
            var halfSize = entity.entitySize / 2

            if (nextX < halfSize || nextX > playfield.width - halfSize) {
                nextVX = -nextVX
                nextX = GameLogic.clamp(nextX, halfSize, playfield.width - halfSize)
            }

            var hitPlayer = hitPlayerForEntity(nextX, nextY, entity.entitySize)
            if (hitPlayer > 0) {
                var collectedType = entity.entityType
                var phaseBeforeCollection = missionPhase
                objectModel.remove(i)
                collectEntity(collectedType, hitPlayer)
                if (gameState !== runningState || phaseBeforeCollection !== missionPhase)
                    return
            } else if (nextY - halfSize > playfield.height) {
                if (!GameLogic.isHazard(entity.entityType))
                    combo = 0
                objectModel.remove(i)
            } else {
                objectModel.setProperty(i, "entityX", nextX)
                objectModel.setProperty(i, "entityY", nextY)
                objectModel.setProperty(i, "entityVX", nextVX)
                objectModel.setProperty(i, "entityRotation",
                                        entity.entityRotation + entity.rotationSpeed * delta)
            }
        }

        updateProjectiles(delta)
    }

    ListModel {
        id: objectModel
        dynamicRoles: true
    }

    ListModel {
        id: projectileModel
        dynamicRoles: true
    }

    Timer {
        interval: 16
        running: true
        repeat: true
        triggeredOnStart: true
        onTriggered: root.advanceFrame()
    }

    Item {
        id: scene
        anchors.fill: parent
        focus: true

        Component.onCompleted: forceActiveFocus()

        Keys.onPressed: function(event) {
            if (event.key === Qt.Key_A && root.gameState === root.runningState) {
                root.p1LeftPressed = true
            } else if (event.key === Qt.Key_D && root.gameState === root.runningState) {
                root.p1RightPressed = true
            } else if (event.key === Qt.Key_Left && root.gameState === root.runningState) {
                if (root.selectedPlayers === 2)
                    root.p2LeftPressed = true
                else
                    root.p1LeftPressed = true
            } else if (event.key === Qt.Key_Right && root.gameState === root.runningState) {
                if (root.selectedPlayers === 2)
                    root.p2RightPressed = true
                else
                    root.p1RightPressed = true
            } else if (event.key === Qt.Key_W && root.gameState === root.runningState) {
                root.p1FirePressed = true
            } else if (event.key === Qt.Key_Up && root.gameState === root.runningState) {
                if (root.selectedPlayers === 2)
                    root.p2FirePressed = true
                else
                    root.p1FirePressed = true
            } else if ((event.key === Qt.Key_Q
                        || (event.key === Qt.Key_Down && root.selectedPlayers === 2))
                       && root.gameState === root.runningState && !event.isAutoRepeat) {
                root.activateBurst()
                event.accepted = true
                return
            } else if (event.key === Qt.Key_Space && !event.isAutoRepeat) {
                if (root.gameState === root.menuState)
                    root.startCampaign()
                else if (root.gameState === root.runningState || root.gameState === root.pausedState)
                    root.togglePause()
                event.accepted = true
                return
            } else if ((event.key === Qt.Key_Return || event.key === Qt.Key_Enter) && !event.isAutoRepeat) {
                if (root.gameState === root.levelClearState)
                    root.advanceToNextLevel()
                else if (root.gameState === root.failedState)
                    root.retryLevel()
                else if (root.gameState === root.campaignClearState) {
                    root.selectedLevel = 1
                    root.startCampaign()
                }
                event.accepted = true
                return
            } else if (event.key === Qt.Key_R && root.gameState === root.failedState && !event.isAutoRepeat) {
                root.retryLevel()
                event.accepted = true
                return
            } else if (event.key === Qt.Key_Escape && root.gameState !== root.menuState) {
                root.goToMenu()
                event.accepted = true
                return
            } else {
                return
            }
            event.accepted = true
        }

        Keys.onReleased: function(event) {
            if (event.key === Qt.Key_A)
                root.p1LeftPressed = false
            else if (event.key === Qt.Key_D)
                root.p1RightPressed = false
            else if (event.key === Qt.Key_Left) {
                if (root.selectedPlayers === 2)
                    root.p2LeftPressed = false
                else
                    root.p1LeftPressed = false
            } else if (event.key === Qt.Key_Right) {
                if (root.selectedPlayers === 2)
                    root.p2RightPressed = false
                else
                    root.p1RightPressed = false
            } else if (event.key === Qt.Key_W) {
                root.p1FirePressed = false
            } else if (event.key === Qt.Key_Up) {
                if (root.selectedPlayers === 2)
                    root.p2FirePressed = false
                else
                    root.p1FirePressed = false
            } else {
                return
            }
            event.accepted = true
        }

        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: "#112044" }
                GradientStop { position: 0.52; color: "#091126" }
                GradientStop { position: 1.0; color: "#030611" }
            }
        }

        Repeater {
            model: 86

            delegate: Rectangle {
                id: backgroundStar
                required property int index
                width: 1 + index % 3
                height: width
                radius: width / 2
                x: (index * 137 + 41) % Math.max(1, scene.width)
                y: (index * 83 + 29) % Math.max(1, scene.height)
                color: index % 7 === 0 ? "#7de8ff" : "white"
                opacity: 0.18 + (index % 5) * 0.1

                SequentialAnimation on opacity {
                    loops: Animation.Infinite
                    NumberAnimation { to: 0.14; duration: 850 + backgroundStar.index * 9 }
                    NumberAnimation { to: 0.68; duration: 1050 + backgroundStar.index * 8 }
                }
            }
        }

        Rectangle {
            id: topBar
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            height: 98
            color: "#8a050a18"
            border.width: 1
            border.color: "#203d6c"
            z: 20

            Row {
                anchors.left: parent.left
                anchors.leftMargin: 18
                anchors.verticalCenter: parent.verticalCenter
                spacing: 10

                HudCard {
                    caption: root.missionPhase === 0 ? qsTr("任务进度") : qsTr("首领耐久")
                    value: root.missionPhase === 0
                           ? root.levelScore + "/" + root.targetScore
                           : root.bossHealth + "/" + root.bossMaxHealth
                    accent: root.missionPhase === 0 ? "#48d9ff" : "#ff6174"
                }

                HudCard {
                    caption: qsTr("P1 生命")
                    value: root.lives1.toString()
                    accent: "#55e6ff"
                }

                HudCard {
                    visible: root.selectedPlayers === 2
                    caption: qsTr("P2 生命")
                    value: root.lives2.toString()
                    accent: "#c287ff"
                }
            }

            Column {
                anchors.centerIn: parent
                spacing: 1

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: root.missionPhase === 0
                          ? qsTr("第 %1 关 · %2").arg(root.currentLevel).arg(String(root.activeConfig.name))
                          : qsTr("首领战 · %1").arg(String(root.activeConfig.bossName))
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 21
                    font.bold: true
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: GameLogic.formatTime(root.timeRemaining)
                    color: root.timeRemaining <= 10 ? "#ff6174" : "#7de8ff"
                    font.family: uiFont.name
                    font.pixelSize: 20
                    font.bold: true
                }
            }

            Row {
                anchors.right: pauseButton.left
                anchors.rightMargin: 12
                anchors.verticalCenter: parent.verticalCenter
                spacing: 10

                HudCard {
                    caption: qsTr("总分")
                    value: root.totalScore.toString()
                    accent: "#ad7cff"
                }

                HudCard {
                    caption: qsTr("连击")
                    value: root.combo > 1 ? "x" + root.combo : "-"
                    accent: "#ffd45a"
                }

                HudCard {
                    caption: qsTr("战术能量")
                    value: root.skillCharge + "%"
                    accent: root.skillCharge >= 100 ? "#67ffe4" : "#52a6ff"
                }
            }

            GameButton {
                id: pauseButton
                anchors.right: parent.right
                anchors.rightMargin: 18
                anchors.verticalCenter: parent.verticalCenter
                width: 92
                compact: true
                text: root.gameState === root.pausedState ? qsTr("继续") : qsTr("暂停")
                accent: "#8b78ff"
                visible: root.gameState === root.runningState || root.gameState === root.pausedState
                onClicked: root.togglePause()
            }

            Rectangle {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                height: 5
                color: "#13213a"

                Rectangle {
                    width: parent.width * (root.missionPhase === 0
                                           ? Math.min(1, root.levelScore / Math.max(1, root.targetScore))
                                           : Math.max(0, root.bossHealth / Math.max(1, root.bossMaxHealth)))
                    height: parent.height
                    color: root.missionPhase === 0
                           ? (root.levelScore >= root.targetScore * 0.8 ? "#ffd45a" : "#48d9ff")
                           : "#ff5874"

                    Behavior on width {
                        NumberAnimation { duration: 180 }
                    }
                }
            }
        }

        Item {
            id: playfield
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: topBar.bottom
            anchors.bottom: parent.bottom
            clip: true

            onWidthChanged: root.placePlayers()

            Repeater {
                model: objectModel

                delegate: FallingObject {
                    required property int entityType
                    required property real entityX
                    required property real entityY
                    required property real entitySize
                    required property real entityRotation

                    width: entitySize
                    height: entitySize
                    x: entityX - width / 2
                    y: entityY - height / 2
                    rotation: entityRotation
                    objectType: entityType
                }
            }

            Repeater {
                model: projectileModel

                delegate: Projectile {
                    required property int projectileOwner
                    required property real projectileX
                    required property real projectileY
                    required property real projectileSize

                    width: projectileOwner === 0 ? projectileSize : 14
                    height: projectileOwner === 0 ? projectileSize : 30
                    x: projectileX - width / 2
                    y: projectileY - height / 2
                    owner: projectileOwner
                    z: 5
                }
            }

            BossShip {
                id: bossItem
                x: root.bossCenterX - width / 2
                y: 38
                level: root.currentLevel
                bossName: String(root.activeConfig.bossName)
                health: root.bossHealth
                maxHealth: root.bossMaxHealth
                hitFlash: root.bossHitFlash
                visible: root.missionPhase === 1
                         && (root.gameState === root.runningState || root.gameState === root.pausedState)
                z: 4
            }

            PlayerShip {
                id: player1
                x: root.player1CenterX - width / 2
                y: playfield.height - height - 20
                playerLabel: "P1"
                accentColor: "#4de9ff"
                flameColor: "#8b6bff"
                shieldActive: root.shield1Remaining > 0
                opacity: root.invulnerable1 > 0 && Math.floor(root.invulnerable1 * 12) % 2 === 0 ? 0.34 : 1
                visible: (root.gameState === root.runningState || root.gameState === root.pausedState) && root.lives1 > 0
            }

            PlayerShip {
                id: player2
                x: root.player2CenterX - width / 2
                y: playfield.height - height - 20
                playerLabel: "P2"
                bodyColor: "#f4ebff"
                accentColor: "#c287ff"
                flameColor: "#ff8ec7"
                shieldActive: root.shield2Remaining > 0
                opacity: root.invulnerable2 > 0 && Math.floor(root.invulnerable2 * 12) % 2 === 0 ? 0.34 : 1
                visible: root.selectedPlayers === 2
                         && (root.gameState === root.runningState || root.gameState === root.pausedState)
                         && root.lives2 > 0
            }

            TapHandler {
                enabled: root.gameState === root.runningState
                acceptedButtons: Qt.LeftButton
                onTapped: function(eventPoint) {
                    var playerIndex = root.pointerPlayerForPosition(eventPoint.position.x)
                    root.movePlayer(playerIndex, eventPoint.position.x)
                }
            }

            TapHandler {
                enabled: root.gameState === root.runningState
                acceptedButtons: Qt.RightButton
                onTapped: function(eventPoint) {
                    root.shoot(root.pointerPlayerForPosition(eventPoint.position.x))
                }
            }

            DragHandler {
                id: dragHandler
                enabled: root.gameState === root.runningState
                target: null
                acceptedButtons: Qt.LeftButton
                yAxis.enabled: false

                onActiveChanged: {
                    if (active) {
                        root.dragPlayer = root.pointerPlayerForPosition(centroid.position.x)
                        root.dragStartCenter = root.dragPlayer === 1 ? root.player1CenterX : root.player2CenterX
                    }
                }

                onTranslationChanged: {
                    if (active)
                        root.movePlayer(root.dragPlayer, root.dragStartCenter + translation.x)
                }
            }

            Rectangle {
                id: damageFlash
                anchors.fill: parent
                color: "#ff2d55"
                opacity: 0
                z: 15
            }

            Rectangle {
                id: burstFlash
                anchors.fill: parent
                color: "#54efff"
                opacity: 0
                z: 15
            }

            Rectangle {
                id: phaseBanner
                anchors.horizontalCenter: parent.horizontalCenter
                y: 34
                width: Math.min(parent.width - 80, 620)
                height: 58
                radius: 16
                color: "#df16142e"
                border.width: 2
                border.color: root.missionPhase === 1 ? "#ff7182" : "#67ffe4"
                opacity: 0
                z: 18

                Text {
                    anchors.centerIn: parent
                    text: root.phaseBannerText
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 18
                    font.bold: true
                }
            }

            Rectangle {
                anchors.centerIn: parent
                width: 190
                height: 46
                radius: 23
                color: "#bf10213d"
                border.width: 1
                border.color: "#67ffe4"
                opacity: shieldAnimation1.running ? 1 : 0
                z: 16

                Text {
                    anchors.centerIn: parent
                    text: qsTr("P1 护盾抵消伤害")
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 15
                    font.bold: true
                }
            }

            Rectangle {
                anchors.centerIn: parent
                width: 190
                height: 46
                radius: 23
                color: "#bf25133d"
                border.width: 1
                border.color: "#d99bff"
                opacity: shieldAnimation2.running ? 1 : 0
                z: 16

                Text {
                    anchors.centerIn: parent
                    text: qsTr("P2 护盾抵消伤害")
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 15
                    font.bold: true
                }
            }

            NumberAnimation {
                id: damageAnimation
                target: damageFlash
                property: "opacity"
                from: 0.44
                to: 0
                duration: 400
            }

            NumberAnimation {
                id: burstAnimation
                target: burstFlash
                property: "opacity"
                from: 0.58
                to: 0
                duration: 520
            }

            SequentialAnimation {
                id: phaseBannerAnimation
                NumberAnimation { target: phaseBanner; property: "opacity"; from: 0; to: 1; duration: 170 }
                PauseAnimation { duration: 1150 }
                NumberAnimation { target: phaseBanner; property: "opacity"; from: 1; to: 0; duration: 350 }
            }

            Timer {
                id: bossHitTimer
                interval: 95
                onTriggered: root.bossHitFlash = false
            }

            NumberAnimation {
                id: shieldAnimation1
                duration: 650
            }

            NumberAnimation {
                id: shieldAnimation2
                duration: 650
            }
        }

        Rectangle {
            anchors.fill: parent
            color: "#db071023"
            visible: root.gameState !== root.runningState
            z: 30

            Column {
                id: menuPanel
                anchors.centerIn: parent
                width: Math.min(parent.width - 70, 860)
                spacing: 12
                visible: root.gameState === root.menuState

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: qsTr("星际守卫：协同防线")
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 43
                    font.bold: true
                    font.letterSpacing: 2
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: qsTr("五关双阶段战役 · 航道任务 + 首领弹幕战 · 本地双人协作")
                    color: "#92a9d0"
                    font.family: uiFont.name
                    font.pixelSize: 17
                }

                Rectangle {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: 690
                    height: 74
                    radius: 14
                    color: "#b011203b"
                    border.width: 1
                    border.color: "#365480"

                    Column {
                        anchors.centerIn: parent
                        spacing: 3

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: qsTr("第 %1 关 · %2 · 目标 %3 分 · %4 秒")
                                  .arg(root.selectedLevel).arg(String(root.previewConfig.name))
                                  .arg(Number(root.previewConfig.targetScore)).arg(Number(root.previewConfig.duration))
                            color: "white"
                            font.family: uiFont.name
                            font.pixelSize: 18
                            font.bold: true
                        }

                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            text: qsTr("%1 · 守关首领：%2")
                                  .arg(String(root.previewConfig.mission))
                                  .arg(String(root.previewConfig.bossName))
                            color: "#9eb2d5"
                            font.family: uiFont.name
                            font.pixelSize: 14
                        }
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 12

                    Text {
                        width: 72
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("游戏模式")
                        color: "#91a7cc"
                        font.family: uiFont.name
                        font.pixelSize: 15
                    }

                    OptionChip {
                        width: 150
                        text: qsTr("单人守卫")
                        selected: root.selectedPlayers === 1
                        accent: "#48d9ff"
                        onClicked: root.selectedPlayers = 1
                    }

                    OptionChip {
                        width: 150
                        text: qsTr("双人协作")
                        selected: root.selectedPlayers === 2
                        accent: "#c287ff"
                        onClicked: root.selectedPlayers = 2
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 12

                    Text {
                        width: 72
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("难度")
                        color: "#91a7cc"
                        font.family: uiFont.name
                        font.pixelSize: 15
                    }

                    OptionChip {
                        width: 112
                        text: qsTr("新手")
                        selected: root.selectedDifficulty === 0
                        accent: "#67e6b1"
                        onClicked: root.selectedDifficulty = 0
                    }

                    OptionChip {
                        width: 112
                        text: qsTr("标准")
                        selected: root.selectedDifficulty === 1
                        accent: "#48d9ff"
                        onClicked: root.selectedDifficulty = 1
                    }

                    OptionChip {
                        width: 112
                        text: qsTr("专家")
                        selected: root.selectedDifficulty === 2
                        accent: "#ff7182"
                        onClicked: root.selectedDifficulty = 2
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 9

                    Text {
                        width: 72
                        anchors.verticalCenter: parent.verticalCenter
                        text: qsTr("选择关卡")
                        color: "#91a7cc"
                        font.family: uiFont.name
                        font.pixelSize: 15
                    }

                    Repeater {
                        model: root.maxLevel

                        delegate: OptionChip {
                            required property int index
                            width: 112
                            text: qsTr("第 %1 关").arg(index + 1)
                            enabled: index + 1 <= Number(root.backend.unlockedLevel)
                            selected: root.selectedLevel === index + 1
                            accent: index === 4 ? "#ffd45a" : "#48d9ff"
                            onClicked: root.selectedLevel = index + 1
                        }
                    }
                }

                GameButton {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: 230
                    text: qsTr("开始第 %1 关").arg(root.selectedLevel)
                    accent: "#48d9ff"
                    onClicked: root.startCampaign()
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: qsTr("收集道具蓄积战术能量 · 激光可摧毁障碍 · 满能量释放爆发 · 通关后三选一强化")
                    color: "#aab9d5"
                    font.family: uiFont.name
                    font.pixelSize: 14
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: root.selectedPlayers === 1
                          ? qsTr("单人：A/D 或 ←/→ 移动 · W/↑ 射击 · Q 爆发 · 鼠标右键射击 · 空格暂停")
                          : qsTr("双人：P1 A/D+W，P2 ←/→+↑ · Q/↓ 爆发 · 鼠标控制最近飞船")
                    color: "#7184a8"
                    font.family: uiFont.name
                    font.pixelSize: 13
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: qsTr("历史最高分：%1 · 已解锁：第 %2 关").arg(Number(root.backend.bestScore))
                          .arg(Number(root.backend.unlockedLevel))
                    color: "#667ca4"
                    font.family: uiFont.name
                    font.pixelSize: 12
                }
            }

            Column {
                id: resultPanel
                anchors.centerIn: parent
                width: Math.min(parent.width - 80, 700)
                spacing: 12
                visible: root.gameState !== root.menuState && root.gameState !== root.runningState

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: {
                        if (root.gameState === root.pausedState)
                            return qsTr("任务已暂停")
                        if (root.gameState === root.levelClearState)
                            return qsTr("第 %1 关通过").arg(root.currentLevel)
                        if (root.gameState === root.campaignClearState)
                            return qsTr("全部关卡完成")
                        return qsTr("本关挑战失败")
                    }
                    color: "white"
                    font.family: uiFont.name
                    font.pixelSize: 46
                    font.bold: true
                    font.letterSpacing: 2
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    wrapMode: Text.WordWrap
                    text: root.gameState === root.pausedState
                          ? (root.missionPhase === 0
                             ? qsTr("%1 · 当前进度 %2/%3 · 剩余 %4")
                               .arg(String(root.activeConfig.mission)).arg(root.levelScore)
                               .arg(root.targetScore).arg(GameLogic.formatTime(root.timeRemaining))
                             : qsTr("正在迎战 %1 · 首领耐久 %2/%3 · 剩余 %4")
                               .arg(String(root.activeConfig.bossName)).arg(root.bossHealth)
                               .arg(root.bossMaxHealth).arg(GameLogic.formatTime(root.timeRemaining)))
                          : root.resultReason
                    color: "#b8c8e6"
                    font.family: uiFont.name
                    font.pixelSize: 18
                }

                Rectangle {
                    anchors.horizontalCenter: parent.horizontalCenter
                    width: 560
                    height: 98
                    radius: 16
                    color: "#b011203b"
                    border.width: 1
                    border.color: root.gameState === root.failedState ? "#794054" : "#365480"

                    Row {
                        anchors.centerIn: parent
                        spacing: 48

                        Column {
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: qsTr("本关得分"); color: "#8398bc"; font.family: uiFont.name; font.pixelSize: 13 }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: root.levelScore; color: "#48d9ff"; font.family: uiFont.name; font.pixelSize: 28; font.bold: true }
                        }

                        Column {
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: qsTr("累计总分"); color: "#8398bc"; font.family: uiFont.name; font.pixelSize: 13 }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: root.totalScore; color: "#c287ff"; font.family: uiFont.name; font.pixelSize: 28; font.bold: true }
                        }

                        Column {
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: qsTr("最高纪录"); color: "#8398bc"; font.family: uiFont.name; font.pixelSize: 13 }
                            Text { anchors.horizontalCenter: parent.horizontalCenter; text: Number(root.backend.bestScore); color: "#ffd45a"; font.family: uiFont.name; font.pixelSize: 28; font.bold: true }
                        }
                    }
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: root.gameState === root.levelClearState
                    text: qsTr("下一关：%1").arg(String(root.backend.levelConfig(root.currentLevel + 1,
                                                                                  root.selectedDifficulty,
                                                                                  root.selectedPlayers).name))
                    color: "#91a7cc"
                    font.family: uiFont.name
                    font.pixelSize: 16
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    visible: root.gameState === root.levelClearState
                    text: qsTr("选择一项舰队强化，效果在后续关卡永久保留")
                    color: "#c8d5ed"
                    font.family: uiFont.name
                    font.pixelSize: 14
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 12
                    visible: root.gameState === root.levelClearState

                    UpgradeCard {
                        title: qsTr("聚能火炮")
                        description: qsTr("激光伤害永久 +1\n当前伤害：%1").arg(root.bulletDamage)
                        iconText: "▲"
                        accent: "#ff7182"
                        selected: root.selectedUpgrade === 0
                        onClicked: root.selectedUpgrade = 0
                    }

                    UpgradeCard {
                        title: qsTr("超频装填")
                        description: qsTr("射击间隔缩短 20%\n当前：%1 秒").arg(root.fireInterval.toFixed(2))
                        iconText: "⚡"
                        accent: "#ffd45a"
                        selected: root.selectedUpgrade === 1
                        onClicked: root.selectedUpgrade = 1
                    }

                    UpgradeCard {
                        title: qsTr("复合装甲")
                        description: qsTr("后续关卡生命上限 +1\n当前加成：%1").arg(root.bonusLives)
                        iconText: "◆"
                        accent: "#67ffe4"
                        selected: root.selectedUpgrade === 2
                        onClicked: root.selectedUpgrade = 2
                    }
                }

                Row {
                    anchors.horizontalCenter: parent.horizontalCenter
                    spacing: 16

                    GameButton {
                        width: 220
                        enabled: root.gameState !== root.levelClearState || root.selectedUpgrade >= 0
                        text: {
                            if (root.gameState === root.pausedState)
                                return qsTr("继续任务")
                            if (root.gameState === root.levelClearState)
                                return root.selectedUpgrade >= 0 ? qsTr("应用强化并进入下一关") : qsTr("请先选择强化")
                            if (root.gameState === root.campaignClearState)
                                return qsTr("从第一关再战")
                            return qsTr("重试本关")
                        }
                        accent: root.gameState === root.failedState ? "#ff7182" : "#48d9ff"
                        onClicked: {
                            if (root.gameState === root.pausedState)
                                root.togglePause()
                            else if (root.gameState === root.levelClearState)
                                root.advanceToNextLevel()
                            else if (root.gameState === root.campaignClearState) {
                                root.selectedLevel = 1
                                root.startCampaign()
                            } else
                                root.retryLevel()
                        }
                    }

                    GameButton {
                        width: 190
                        text: qsTr("返回主菜单")
                        accent: "#8b78ff"
                        onClicked: root.goToMenu()
                    }
                }

                Text {
                    anchors.horizontalCenter: parent.horizontalCenter
                    text: qsTr("Enter 确认 · Esc 返回菜单")
                    color: "#7184a8"
                    font.family: uiFont.name
                    font.pixelSize: 13
                }
            }
        }
    }
}
