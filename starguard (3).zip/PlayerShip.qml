import QtQuick

Item {
    id: root

    property string playerLabel: "P1"
    property color bodyColor: "#e8f5ff"
    property color accentColor: "#4de9ff"
    property color flameColor: "#8b6bff"
    property bool shieldActive: false

    implicitWidth: 82
    implicitHeight: 66

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.top
        anchors.bottomMargin: 4
        text: root.playerLabel
        color: root.accentColor
        font.family: uiFont.name
        font.pixelSize: 13
        font.bold: true
    }

    Rectangle {
        anchors.centerIn: parent
        width: parent.width + 18
        height: parent.height + 14
        radius: width / 2
        color: "transparent"
        border.width: 3
        border.color: root.accentColor
        opacity: root.shieldActive ? 0.78 : 0

        SequentialAnimation on opacity {
            running: root.shieldActive
            loops: Animation.Infinite
            NumberAnimation { to: 0.34; duration: 340 }
            NumberAnimation { to: 0.86; duration: 340 }
        }
    }

    Rectangle {
        width: 11
        height: 18
        x: 21
        y: 46
        radius: width / 2
        color: root.accentColor
        opacity: 0.85

        SequentialAnimation on scale {
            loops: Animation.Infinite
            NumberAnimation { to: 0.66; duration: 100 }
            NumberAnimation { to: 1.08; duration: 130 }
        }
    }

    Rectangle {
        width: 11
        height: 18
        x: 50
        y: 46
        radius: width / 2
        color: root.flameColor
        opacity: 0.85

        SequentialAnimation on scale {
            loops: Animation.Infinite
            NumberAnimation { to: 1.1; duration: 120 }
            NumberAnimation { to: 0.64; duration: 105 }
        }
    }

    Canvas {
        id: shipCanvas
        anchors.fill: parent

        onPaint: {
            var ctx = getContext("2d")
            ctx.clearRect(0, 0, width, height)

            ctx.beginPath()
            ctx.moveTo(width / 2, 2)
            ctx.lineTo(width - 7, height - 16)
            ctx.lineTo(width * 0.67, height - 20)
            ctx.lineTo(width * 0.57, height - 8)
            ctx.lineTo(width * 0.43, height - 8)
            ctx.lineTo(width * 0.33, height - 20)
            ctx.lineTo(7, height - 16)
            ctx.closePath()
            ctx.fillStyle = root.bodyColor
            ctx.fill()
            ctx.lineWidth = 2
            ctx.strokeStyle = root.accentColor
            ctx.stroke()

            ctx.beginPath()
            ctx.moveTo(width / 2, 10)
            ctx.lineTo(width * 0.65, height * 0.64)
            ctx.lineTo(width * 0.35, height * 0.64)
            ctx.closePath()
            ctx.fillStyle = "#162d58"
            ctx.fill()
        }
    }

    Rectangle {
        width: 18
        height: 18
        anchors.horizontalCenter: parent.horizontalCenter
        y: 18
        radius: 9
        color: root.accentColor
        border.width: 2
        border.color: "white"
    }

    onBodyColorChanged: shipCanvas.requestPaint()
    onAccentColorChanged: shipCanvas.requestPaint()
}
