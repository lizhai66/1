import QtQuick

Item {
    id: root

    property string title: "强化"
    property string description: "提升战斗能力"
    property string iconText: "◆"
    property bool selected: false
    property color accent: "#48d9ff"
    signal clicked()

    implicitWidth: 190
    implicitHeight: 116
    scale: tapHandler.pressed ? 0.97 : 1

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    Rectangle {
        anchors.fill: parent
        radius: 15
        color: root.selected ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.2)
                             : (hoverHandler.hovered ? "#203657" : "#132540")
        border.width: root.selected ? 3 : 1
        border.color: root.selected ? root.accent : "#38537c"
    }

    Column {
        anchors.centerIn: parent
        width: parent.width - 22
        spacing: 4

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.iconText
            color: root.accent
            font.family: uiFont.name
            font.pixelSize: 23
            font.bold: true
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.title
            color: "white"
            font.family: uiFont.name
            font.pixelSize: 16
            font.bold: true
        }

        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: root.description
            color: "#9eb1d2"
            font.family: uiFont.name
            font.pixelSize: 12
        }
    }

    HoverHandler {
        id: hoverHandler
    }

    TapHandler {
        id: tapHandler
        acceptedButtons: Qt.LeftButton
        onTapped: root.clicked()
    }

    Behavior on scale {
        NumberAnimation { duration: 80 }
    }
}
