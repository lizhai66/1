#pragma once

#include <QObject>
#include <QSettings>
#include <QVariantMap>

class GameBackend : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int bestScore READ bestScore NOTIFY progressChanged)
    Q_PROPERTY(int unlockedLevel READ unlockedLevel NOTIFY progressChanged)

public:
    explicit GameBackend(QObject *parent = nullptr);

    int bestScore() const;
    int unlockedLevel() const;

    Q_INVOKABLE QVariantMap levelConfig(int level, int difficulty, int players) const;
    Q_INVOKABLE void submitResult(int level, int score, bool victory);
    Q_INVOKABLE void resetProgress();

signals:
    void progressChanged();

private:
    QSettings m_settings;
    int m_bestScore = 0;
    int m_unlockedLevel = 1;
};
