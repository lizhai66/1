import QtQuick

Item {
    id: root

    property int owner: 1

    Rectangle {
        visible: root.owner > 0
        anchors.centerIn: parent
        width: root.owner === 1 ? 5 : 7
        height: parent.height
        radius: width / 2
        color: root.owner === 1 ? "#63efff" : "#d39bff"
        border.width: 1
        border.color: "white"

        Rectangle {
            anchors.centerIn: parent
            width: parent.width + 10
            height: parent.height + 8
            radius: width / 2
            color: root.owner === 1 ? "#2863efff" : "#28d39bff"
        }
    }

    Rectangle {
        visible: root.owner === 0
        anchors.centerIn: parent
        width: parent.width
        height: width
        radius: width / 2
        color: "#ff5874"
        border.width: 2
        border.color: "#ffd1d9"

        SequentialAnimation on scale {
            loops: Animation.Infinite
            NumberAnimation { to: 1.18; duration: 170 }
            NumberAnimation { to: 0.86; duration: 170 }
        }
    }
}
