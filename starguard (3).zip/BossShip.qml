import QtQuick

Item {
    id: root

    property int level: 1
    property string bossName: "守关首领"
    property int health: 1
    property int maxHealth: 1
    property bool hitFlash: false

    implicitWidth: 178
    implicitHeight: 118

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.top
        anchors.bottomMargin: 6
        text: root.bossName
        color: "#ffb0c4"
        font.family: uiFont.name
        font.pixelSize: 15
        font.bold: true
    }

    Rectangle {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        width: parent.width
        height: 8
        radius: 4
        color: "#3a1729"

        Rectangle {
            width: parent.width * Math.max(0, root.health) / Math.max(1, root.maxHealth)
            height: parent.height
            radius: 4
            color: root.health < root.maxHealth * 0.3 ? "#ffcc59" : "#ff5874"

            Behavior on width {
                NumberAnimation { duration: 130 }
            }
        }
    }

    Item {
        anchors.fill: parent
        anchors.topMargin: 14
        opacity: root.hitFlash ? 0.45 : 1

        Rectangle {
            anchors.centerIn: parent
            width: 108
            height: 76
            radius: 22
            color: root.level >= 4 ? "#542064" : "#7c2445"
            border.width: 4
            border.color: root.level >= 4 ? "#db8cff" : "#ff849d"
            rotation: 45
        }

        Rectangle {
            anchors.centerIn: parent
            width: 58
            height: 58
            radius: width / 2
            color: "#10172f"
            border.width: 4
            border.color: "#ffcf70"

            Rectangle {
                anchors.centerIn: parent
                width: 22
                height: width
                radius: width / 2
                color: "#ff5874"
            }
        }

        Rectangle {
            x: 8
            anchors.verticalCenter: parent.verticalCenter
            width: 52
            height: 16
            radius: 8
            color: "#c33c61"
            border.width: 2
            border.color: "#ffb0c4"
        }

        Rectangle {
            anchors.right: parent.right
            anchors.rightMargin: 8
            anchors.verticalCenter: parent.verticalCenter
            width: 52
            height: 16
            radius: 8
            color: "#c33c61"
            border.width: 2
            border.color: "#ffb0c4"
        }

        SequentialAnimation on scale {
            loops: Animation.Infinite
            NumberAnimation { to: 1.04; duration: 520; easing.type: Easing.InOutSine }
            NumberAnimation { to: 0.97; duration: 520; easing.type: Easing.InOutSine }
        }
    }
}
