import QtQuick

Item {
    id: root

    property string text: "按钮"
    property color accent: "#48d9ff"
    property bool compact: false
    signal clicked()

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    implicitWidth: compact ? 108 : 210
    implicitHeight: compact ? 42 : 58
    scale: tapHandler.pressed ? 0.96 : 1.0
    opacity: enabled ? 1.0 : 0.38

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: hoverHandler.hovered && root.enabled ? Qt.lighter(root.accent, 1.12) : root.accent
        border.width: 1
        border.color: "#bff6ff"
        opacity: tapHandler.pressed ? 0.82 : 1.0
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: 4
        radius: height / 2
        color: "transparent"
        border.width: 1
        border.color: "#55ffffff"
    }

    Text {
        anchors.centerIn: parent
        text: root.text
        color: "#061221"
        font.family: uiFont.name
        font.pixelSize: root.compact ? 16 : 20
        font.bold: true
        elide: Text.ElideRight
    }

    HoverHandler {
        id: hoverHandler
    }

    TapHandler {
        id: tapHandler
        enabled: root.enabled
        acceptedButtons: Qt.LeftButton
        onTapped: root.clicked()
    }

    Behavior on scale {
        NumberAnimation { duration: 90 }
    }
}
