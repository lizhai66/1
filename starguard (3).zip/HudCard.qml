import QtQuick

Item {
    id: root

    property string caption: "得分"
    property string value: "0"
    property color accent: "#48d9ff"

    FontLoader {
        id: uiFont
        source: "assets/NotoSansSC.otf"
    }

    implicitWidth: 116
    implicitHeight: 66

    Rectangle {
        anchors.fill: parent
        radius: 12
        color: "#99101d36"
        border.width: 1
        border.color: Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.55)
    }

    Rectangle {
        width: 4
        height: parent.height - 18
        anchors.left: parent.left
        anchors.leftMargin: 7
        anchors.verticalCenter: parent.verticalCenter
        radius: 2
        color: root.accent
    }

    Column {
        anchors.centerIn: parent
        spacing: 2

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.caption
            color: "#8295b8"
            font.family: uiFont.name
            font.pixelSize: 11
            font.letterSpacing: 1.5
            font.bold: true
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.value
            color: "white"
            font.family: uiFont.name
            font.pixelSize: 21
            font.bold: true
        }
    }
}
