import QtQuick

Item {
    id: root

    property int objectType: 0

    Rectangle {
        visible: root.objectType === 0
        anchors.centerIn: parent
        width: parent.width
        height: width
        radius: width / 2
        color: "#224de9ff"
        border.width: 2
        border.color: "#704de9ff"

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.62
            height: width
            radius: width / 2
            color: "#4de9ff"
            border.width: 3
            border.color: "#dcfbff"
        }
    }

    Item {
        visible: root.objectType === 1
        anchors.fill: parent

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "#db5461"
            border.width: 3
            border.color: "#ff9d76"
        }

        Rectangle {
            width: parent.width * 0.3
            height: width
            x: parent.width * 0.18
            y: parent.height * 0.2
            radius: width / 2
            color: "#8e3348"
        }

        Rectangle {
            width: parent.width * 0.2
            height: width
            x: parent.width * 0.58
            y: parent.height * 0.55
            radius: width / 2
            color: "#8e3348"
        }
    }

    Canvas {
        visible: root.objectType === 2
        anchors.fill: parent

        onPaint: {
            var ctx = getContext("2d")
            var cx = width / 2
            var cy = height / 2
            ctx.clearRect(0, 0, width, height)
            ctx.beginPath()
            for (var i = 0; i < 10; ++i) {
                var radius = i % 2 === 0 ? width * 0.48 : width * 0.21
                var angle = -Math.PI / 2 + i * Math.PI / 5
                var px = cx + Math.cos(angle) * radius
                var py = cy + Math.sin(angle) * radius
                if (i === 0)
                    ctx.moveTo(px, py)
                else
                    ctx.lineTo(px, py)
            }
            ctx.closePath()
            ctx.fillStyle = "#ffd45a"
            ctx.fill()
            ctx.lineWidth = 3
            ctx.strokeStyle = "#fff4b3"
            ctx.stroke()
        }
    }

    Item {
        visible: root.objectType === 3
        anchors.fill: parent

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.9
            height: width
            radius: width / 2
            color: "#1638e9c8"
            border.width: 4
            border.color: "#67ffe4"
        }

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.46
            height: width
            radius: width / 2
            color: "transparent"
            border.width: 3
            border.color: "white"
        }
    }

    Item {
        visible: root.objectType === 4
        anchors.fill: parent

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.7
            height: width
            rotation: 45
            radius: 8
            color: "#ff7b54"
            border.width: 3
            border.color: "#ffd0a8"
        }

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.28
            height: width
            radius: width / 2
            color: "#651b35"
            border.width: 2
            border.color: "white"
        }
    }

    Item {
        visible: root.objectType === 5
        anchors.fill: parent

        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "#35d49a"
            border.width: 3
            border.color: "#d6fff1"
        }

        Rectangle {
            width: 3
            height: parent.height * 0.27
            anchors.horizontalCenter: parent.horizontalCenter
            y: parent.height * 0.22
            color: "#083c3a"
        }

        Rectangle {
            width: parent.width * 0.24
            height: 3
            x: parent.width * 0.5
            y: parent.height * 0.49
            rotation: 28
            transformOrigin: Item.Left
            color: "#083c3a"
        }
    }

    Item {
        visible: root.objectType === 6
        anchors.fill: parent

        Rectangle {
            anchors.centerIn: parent
            width: parent.width
            height: width
            radius: width / 2
            color: "#26103f"
            border.width: 7
            border.color: "#b66cff"
        }

        Rectangle {
            anchors.centerIn: parent
            width: parent.width * 0.58
            height: width
            radius: width / 2
            color: "#02030a"
            border.width: 3
            border.color: "#f05cff"
        }
    }

    SequentialAnimation on scale {
        running: root.objectType !== 1 && root.objectType !== 4
        loops: Animation.Infinite
        NumberAnimation { to: 1.08; duration: 330; easing.type: Easing.InOutSine }
        NumberAnimation { to: 0.95; duration: 330; easing.type: Easing.InOutSine }
    }
}
