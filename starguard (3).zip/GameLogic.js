.pragma library

var levelNames = ["新兵航道", "陨石边境", "风暴星云", "双子裂隙", "终极防线"]
var levelMissions = [
    "收集能量，熟悉飞船操控",
    "高速无人机将加入陨石群",
    "能见度下降，危险持续增强",
    "黑洞出现，注意横向移动",
    "完成最终守卫并刷新纪录"
]
var bossNames = ["红岩督军", "猎隼指挥机", "星云吞噬者", "裂隙守望者", "零号母舰"]
var baseTargets = [180, 320, 480, 650, 850]
var baseDurations = [35, 40, 45, 50, 55]
var baseSpawnIntervals = [0.72, 0.63, 0.55, 0.48, 0.42]
var baseHazardRates = [0.24, 0.30, 0.36, 0.41, 0.46]
var baseBossHealth = [34, 54, 78, 112, 158]
var bossTimeBonuses = [22, 24, 27, 30, 34]
var baseBossFireIntervals = [1.18, 1.02, 0.88, 0.74, 0.62]

function clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, value))
}

function levelConfig(level, difficulty, players) {
    var safeLevel = Math.round(clamp(level, 1, 5))
    var safeDifficulty = Math.round(clamp(difficulty, 0, 2))
    var safePlayers = Math.round(clamp(players, 1, 2))
    var index = safeLevel - 1
    var targetScale = [0.82, 1.0, 1.18][safeDifficulty]
    var speedScale = [0.84, 1.0, 1.24][safeDifficulty]
    var spawnScale = [1.16, 1.0, 0.82][safeDifficulty]
    var hazardOffset = [-0.05, 0.0, 0.07][safeDifficulty]
    var lives = [5, 4, 3][safeDifficulty]

    return {
        name: levelNames[index],
        mission: levelMissions[index],
        bossName: bossNames[index],
        difficultyName: ["新手", "标准", "专家"][safeDifficulty],
        targetScore: Math.round(baseTargets[index] * targetScale * (safePlayers === 2 ? 1.45 : 1.0)),
        duration: baseDurations[index],
        startingLives: lives,
        spawnInterval: baseSpawnIntervals[index] * spawnScale,
        speedMultiplier: speedScale,
        hazardRate: clamp(baseHazardRates[index] + hazardOffset, 0.16, 0.64),
        bossHealth: Math.round(baseBossHealth[index] * targetScale * (safePlayers === 2 ? 1.55 : 1.0)),
        bossTimeBonus: bossTimeBonuses[index],
        bossFireInterval: baseBossFireIntervals[index] * spawnScale
    }
}

function currentSpawnInterval(baseInterval, progress) {
    return Math.max(0.19, baseInterval * (1.0 - clamp(progress, 0, 1) * 0.18))
}

function createEntity(fieldWidth, level, config, id) {
    var hazardRate = Number(config.hazardRate)
    var blackHoleChance = level >= 4 ? hazardRate * 0.10 : 0
    var droneChance = level >= 2 ? hazardRate * (0.17 + level * 0.012) : 0
    var meteorChance = Math.max(0, hazardRate - blackHoleChance - droneChance)
    var roll = Math.random()
    var type

    if (roll < blackHoleChance)
        type = 6
    else if (roll < blackHoleChance + droneChance)
        type = 4
    else if (roll < blackHoleChance + droneChance + meteorChance)
        type = 1
    else if (roll < hazardRate + 0.10)
        type = 2
    else if (roll < hazardRate + 0.17)
        type = 3
    else if (roll < hazardRate + 0.22)
        type = 5
    else
        type = 0

    var sizeByType = [38, 54, 46, 43, 52, 42, 74]
    var size = sizeByType[type] + (type === 1 ? Math.random() * 17 : 0)
    var margin = size * 0.65
    var x = margin + Math.random() * Math.max(1, fieldWidth - margin * 2)
    var speedFactor = [1.0, 1.02, 1.12, 0.92, 1.32, 1.24, 0.78][type]
    var baseSpeed = 126 + level * 17 + Math.random() * 62
    var speed = baseSpeed * Number(config.speedMultiplier) * speedFactor
    var horizontalSpeed = 0

    if (type === 4)
        horizontalSpeed = (Math.random() < 0.5 ? -1 : 1) * (92 + Math.random() * 80)
    else if (type === 6)
        horizontalSpeed = (Math.random() < 0.5 ? -1 : 1) * (30 + Math.random() * 35)

    return {
        entityId: id,
        entityType: type,
        entityX: x,
        entityY: -size,
        entitySize: size,
        entitySpeed: speed,
        entityVX: horizontalSpeed,
        entityRotation: Math.random() * 360,
        rotationSpeed: (Math.random() < 0.5 ? -1 : 1) * (32 + Math.random() * 105)
    }
}

function intersects(ax, ay, aw, ah, bx, by, bw, bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by
}

function scoreForType(type, combo) {
    var bonus = Math.min(combo, 12)
    if (type === 2)
        return 42 + bonus * 4
    if (type === 3)
        return 18 + bonus * 2
    if (type === 5)
        return 24 + bonus * 2
    if (type === 0)
        return 12 + bonus * 2
    return 0
}

function damageForType(type) {
    return type === 6 ? 2 : (type === 1 || type === 4 ? 1 : 0)
}

function destroyScore(type) {
    if (type === 6)
        return 24
    if (type === 4)
        return 16
    if (type === 1)
        return 8
    return 0
}

function isHazard(type) {
    return type === 1 || type === 4 || type === 6
}

function formatTime(seconds) {
    var whole = Math.max(0, Math.ceil(seconds))
    var minutes = Math.floor(whole / 60)
    var remainingSeconds = whole % 60
    return (minutes < 10 ? "0" : "") + minutes + ":"
            + (remainingSeconds < 10 ? "0" : "") + remainingSeconds
}
