#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QVariantMap>

#include "gamebackend.h"

#include <cstdlib>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    QGuiApplication::setApplicationName(QStringLiteral("StarGuard"));
    QGuiApplication::setOrganizationName(QStringLiteral("2024051507280lizenghai"));

    GameBackend backend;
    QQmlApplicationEngine engine;
    QVariantMap initialProperties;
    initialProperties.insert(
        QStringLiteral("backend"), QVariant::fromValue(static_cast<QObject *>(&backend)));
    engine.setInitialProperties(initialProperties);
    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(EXIT_FAILURE); },
        Qt::QueuedConnection);
    engine.loadFromModule("StarGuard", "Main");

    return app.exec();
}
